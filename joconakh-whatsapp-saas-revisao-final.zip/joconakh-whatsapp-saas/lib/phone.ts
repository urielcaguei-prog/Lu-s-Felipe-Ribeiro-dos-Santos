export function normalizePhone(input:string){
  const raw=input.trim().replace(/\D/g,'')
  if(!raw) return null
  let n=raw
  if(n.startsWith('55') && n.length>=12) return n
  if(n.length===10 || n.length===11) return `55${n}`
  return n.length>=11 ? n : null
}
export function jid(phone:string){return `${phone}@s.whatsapp.net`}
