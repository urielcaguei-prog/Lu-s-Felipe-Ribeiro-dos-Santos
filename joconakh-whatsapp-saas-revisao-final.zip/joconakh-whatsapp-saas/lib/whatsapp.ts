import makeWASocket, { DisconnectReason, type WASocket, useMultiFileAuthState } from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'
import QRCode from 'qrcode'
import P from 'pino'
import path from 'node:path'
import fs from 'node:fs/promises'
import { prisma } from './prisma'
import { jid } from './phone'

type State={sock?:WASocket; starting?:Promise<WASocket>; qrDataUrl?:string; pairingCode?:string; status:'DISCONNECTED'|'CONNECTING'|'QR_READY'|'CONNECTED'|'ERROR'; phone?:string; error?:string; registered?:boolean}
const g=globalThis as unknown as { wa?:State }
const state=g.wa ?? {status:'DISCONNECTED' as const}; g.wa=state
const authDir=path.resolve(process.env.WA_AUTH_DIR || './.data/baileys')

async function persist(patch:Partial<State>){Object.assign(state,patch); await prisma.whatsAppSession.upsert({where:{id:'principal'},create:{id:'principal',name:'principal',status:state.status,phone:state.phone,qrDataUrl:state.qrDataUrl,pairingCode:state.pairingCode,lastError:state.error},update:{status:state.status,phone:state.phone,qrDataUrl:state.qrDataUrl,pairingCode:state.pairingCode,lastError:state.error}}).catch(()=>{})}

export async function connect(){
  if(state.sock && state.status==='CONNECTED') return state.sock
  if(state.starting) return state.starting
  state.starting=(async()=>{
    await fs.mkdir(authDir,{recursive:true})
    const {state:auth,saveCreds}=await useMultiFileAuthState(authDir)
    await persist({status:'CONNECTING',error:undefined,qrDataUrl:undefined,pairingCode:undefined,registered:auth.creds.registered})
    const sock=makeWASocket({auth,logger:P({level:'silent'}),markOnlineOnConnect:false})
    state.sock=sock
    sock.ev.on('creds.update',saveCreds)
    sock.ev.on('messages.upsert',async({messages})=>{
      for(const m of messages){
        const text=String(m.message?.conversation || m.message?.extendedTextMessage?.text || '').trim().toUpperCase()
        const remote=m.key.remoteJid || ''
        if(m.key.fromMe || !remote.endsWith('@s.whatsapp.net')) continue
        if(['SAIR','PARAR','STOP','CANCELAR'].includes(text)){
          const phone=remote.split('@')[0].split(':')[0]
          await prisma.contact.updateMany({where:{phone},data:{optIn:false,optedOutAt:new Date()}}).catch(()=>{})
          await prisma.auditLog.create({data:{action:'OPT_OUT',subject:phone,detail:`Opt-out recebido: ${text}`}}).catch(()=>{})
        }
      }
    })
    sock.ev.on('connection.update',async(update)=>{
      if(update.qr){state.qrDataUrl=await QRCode.toDataURL(update.qr,{margin:1,width:360});await persist({status:'QR_READY',qrDataUrl:state.qrDataUrl,pairingCode:undefined})}
      if(update.connection==='open'){
        const me=sock.user?.id?.split(':')[0]?.split('@')[0]
        await persist({status:'CONNECTED',phone:me,qrDataUrl:undefined,pairingCode:undefined,error:undefined,registered:true})
      }
      if(update.connection==='close'){
        const code=(update.lastDisconnect?.error as Boom)?.output?.statusCode
        state.sock=undefined
        await persist({status:code===DisconnectReason.loggedOut?'DISCONNECTED':'ERROR',error:String(update.lastDisconnect?.error||'connection closed')})
        if(code!==DisconnectReason.loggedOut) setTimeout(()=>connect().catch(()=>{}),3000)
      }
    })
    return sock
  })()
  try{return await state.starting} finally{state.starting=undefined}
}

export async function getStatus(){
  const row=await prisma.whatsAppSession.findUnique({where:{id:'principal'}}).catch(()=>null)
  return {status:state.status,phone:state.phone,qrDataUrl:state.qrDataUrl,pairingCode:state.pairingCode,error:state.error,db:row}
}
export async function requestPairingCode(phone:string){
  const sock=await connect()
  if(state.registered) throw new Error('Já existe uma sessão registrada. Desconecte a sessão antes de solicitar outro código.')
  if(typeof (sock as any).requestPairingCode!=='function') throw new Error('Esta versão do Baileys não expõe código de pareamento.')
  const code=await (sock as any).requestPairingCode(phone.replace(/\D/g,''))
  await persist({pairingCode:code,status:'QR_READY'})
  return code
}
export async function disconnect(){
  if(state.sock){try{state.sock.end(undefined)}catch{} state.sock=undefined}
  await persist({status:'DISCONNECTED',phone:undefined,qrDataUrl:undefined,pairingCode:undefined})
}
export async function sendText(phone:string,text:string){const sock=await connect();if(state.status!=='CONNECTED') throw new Error('WhatsApp não está conectado.');return sock.sendMessage(jid(phone),{text})}
export async function sendAttachment(phone:string,file:{buffer:Buffer;mimeType:string;filename:string;type:'IMAGE'|'VIDEO'|'AUDIO'|'DOCUMENT'},caption?:string){
  const sock=await connect();if(state.status!=='CONNECTED') throw new Error('WhatsApp não está conectado.')
  const content:any={caption}
  if(file.type==='IMAGE') content.image=file.buffer
  else if(file.type==='VIDEO') content.video=file.buffer
  else if(file.type==='AUDIO') {content.audio=file.buffer;content.mimetype=file.mimeType;content.ptt=false}
  else {content.document=file.buffer;content.mimetype=file.mimeType;content.fileName=file.filename}
  if(file.type==='IMAGE'||file.type==='VIDEO') content.mimetype=file.mimeType
  return sock.sendMessage(jid(phone),content)
}
