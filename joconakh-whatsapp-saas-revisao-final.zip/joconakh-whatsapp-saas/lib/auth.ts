import crypto from 'node:crypto'
import { cookies } from 'next/headers'
const COOKIE='joconakh_session'
const secret=()=>process.env.SESSION_SECRET||'dev-secret-change-me'
function sign(v:string){return crypto.createHmac('sha256',secret()).update(v).digest('hex')}
export function makeSession(email:string){return `${email}.${sign(email)}`}
export function validSession(value?:string){if(!value)return false;const i=value.lastIndexOf('.');if(i<1)return false;const email=value.slice(0,i);const sig=value.slice(i+1);const expected=sign(email);if(sig.length!==expected.length)return false;return crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))}
export async function isAuthed(){const c=await cookies();return validSession(c.get(COOKIE)?.value)}
export async function requireAuth(){if(!(await isAuthed())) throw new Error('UNAUTHORIZED')}
export { COOKIE }
