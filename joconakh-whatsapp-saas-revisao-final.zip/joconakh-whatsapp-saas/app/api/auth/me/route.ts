import { NextResponse } from 'next/server'; import { isAuthed } from '@/lib/auth'
export async function GET(){return NextResponse.json({authenticated:await isAuthed(),name:'Luis Felipe Ribeiro dos Santos'})}
