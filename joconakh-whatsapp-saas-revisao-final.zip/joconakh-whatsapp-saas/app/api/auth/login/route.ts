import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { makeSession, COOKIE } from '@/lib/auth'
export const runtime='nodejs'
export async function POST(req:Request){
 const {email,password}=await req.json()
 if(email!==process.env.ADMIN_EMAIL||password!==process.env.ADMIN_PASSWORD)return NextResponse.json({error:'Credenciais inválidas'},{status:401})
 const c=await cookies();c.set(COOKIE,makeSession(email),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:60*60*24*7})
 return NextResponse.json({ok:true})
}
