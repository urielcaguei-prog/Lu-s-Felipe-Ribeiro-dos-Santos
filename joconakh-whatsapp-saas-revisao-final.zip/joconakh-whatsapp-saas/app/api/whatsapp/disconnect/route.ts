import { NextResponse } from 'next/server'; import { disconnect } from '@/lib/whatsapp'; import { isAuthed } from '@/lib/auth'
export const runtime='nodejs'; export async function POST(){if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401});await disconnect();return NextResponse.json({ok:true})}
