import { NextResponse } from 'next/server'; import { connect } from '@/lib/whatsapp'; import { isAuthed } from '@/lib/auth'
export const runtime='nodejs'; export const maxDuration=60
export async function POST(){if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401});await connect();return NextResponse.json({ok:true})}
