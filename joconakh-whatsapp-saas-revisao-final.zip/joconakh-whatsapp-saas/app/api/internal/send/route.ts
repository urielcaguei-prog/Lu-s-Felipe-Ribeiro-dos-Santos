import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { sendText, sendAttachment } from '@/lib/whatsapp'
import fs from 'node:fs/promises'

export const runtime = 'nodejs'

export async function POST(req: Request) {
  if (req.headers.get('x-internal-secret') !== (process.env.INTERNAL_API_SECRET || '')) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 })
  }

  const { messageId } = await req.json()
  const msg = await prisma.campaignMessage.findUnique({
    where: { id: messageId },
    include: { contact: true, campaign: { include: { attachments: true } } },
  })

  if (!msg) return NextResponse.json({ error: 'message not found' }, { status: 404 })
  if (msg.status === 'OPTED_OUT' || !msg.contact.optIn) {
    return NextResponse.json({ ok: true, skipped: true })
  }

  await prisma.campaignMessage.update({ where: { id: msg.id }, data: { status: 'PROCESSING' } })

  try {
    const body = msg.campaign.body.replace(/\{\{primeiro_nome\}\}/gi, msg.contact.firstName || msg.contact.name || '')
    const attachments = msg.campaign.attachments

    if (attachments.length) {
      for (const a of attachments) {
        const buffer = await fs.readFile(a.path)
        await sendAttachment(
          msg.contact.phone,
          { buffer, mimeType: a.mimeType, filename: a.filename, type: a.type },
          body || undefined,
        )
      }
    } else {
      await sendText(msg.contact.phone, body)
    }

    await prisma.campaignMessage.update({
      where: { id: msg.id },
      data: { status: 'SENT', sentAt: new Date(), error: null },
    })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    await prisma.campaignMessage.update({
      where: { id: msg.id },
      data: { status: 'FAILED', error: String(e?.message || e) },
    })
    return NextResponse.json({ error: String(e?.message || e) }, { status: 500 })
  }
}
