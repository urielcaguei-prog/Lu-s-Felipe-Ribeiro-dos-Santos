import { NextResponse } from 'next/server'; import { prisma } from '@/lib/prisma'; import { isAuthed } from '@/lib/auth'
export const runtime='nodejs'
export async function GET(){if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401});return NextResponse.json(await prisma.contact.findMany({orderBy:{createdAt:'desc'},take:500}))}
