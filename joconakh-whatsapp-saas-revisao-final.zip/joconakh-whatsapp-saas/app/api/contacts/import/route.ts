import { NextResponse } from 'next/server'; import { prisma } from '@/lib/prisma'; import { isAuthed } from '@/lib/auth'; import { normalizePhone } from '@/lib/phone'
export const runtime='nodejs'
export async function POST(req:Request){
 if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401})
 const {text,optIn=true}=await req.json(); const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean)
 let imported=0, skipped=0
 for(const line of lines){const [phoneRaw,nameRaw]=line.split('|').map(s=>s?.trim());const phone=normalizePhone(phoneRaw||'');if(!phone){skipped++;continue}const name=nameRaw||null;await prisma.contact.upsert({where:{phone},create:{phone,name,firstName:name?.split(/\s+/)[0]||null,optIn},update:{name:name??undefined,firstName:name?.split(/\s+/)[0]||undefined,optIn}});imported++}
 await prisma.auditLog.create({data:{action:'CONTACT_IMPORT',subject:'contacts',detail:`${imported} importados; ${skipped} ignorados`}})
 return NextResponse.json({imported,skipped})
}
