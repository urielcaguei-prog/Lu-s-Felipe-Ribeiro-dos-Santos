import { NextResponse } from 'next/server'; import { prisma } from '@/lib/prisma'; import { isAuthed } from '@/lib/auth'; import { campaignQueue } from '@/lib/queue'; import { normalizePhone } from '@/lib/phone'
export const runtime='nodejs'
export async function GET(){if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401});return NextResponse.json(await prisma.campaign.findMany({include:{_count:{select:{messages:true}}},orderBy:{createdAt:'desc'},take:50}))}
export async function POST(req:Request){
 if(!(await isAuthed()))return NextResponse.json({error:'UNAUTHORIZED'},{status:401})
 const b=await req.json();
 const phones=Array.isArray(b.phones)?b.phones:[];
 const rawPhoneText=String(b.phoneText||'');
 const directPhones=rawPhoneText.split(/\r?\n/).map((line:string)=>normalizePhone(line.split('|')[0].trim())).filter((x): x is string=>Boolean(x));
 const ids=[...new Set([...phones,...directPhones])];
 if(directPhones.length && b.confirmOptIn!==true) return NextResponse.json({error:'Confirme que todos os números possuem autorização (opt-in).'}, {status:400});
 if(directPhones.length){
   for(const line of rawPhoneText.split(/\r?\n/).map((x:string)=>x.trim()).filter(Boolean)){
     const [phoneRaw,name]=line.split('|').map((x:string)=>x.trim());
     const phone=normalizePhone(phoneRaw||'');
     if(phone) await prisma.contact.upsert({where:{phone},create:{phone,name:name||null,firstName:name?.split(/\s+/)[0]||null,optIn:true},update:{name:name||undefined,firstName:name?.split(/\s+/)[0]||undefined,optIn:true,optedOutAt:null}});
   }
 }
 const contacts=await prisma.contact.findMany({where:{phone:{in:ids},optIn:true}})
 const c=await prisma.campaign.create({data:{name:String(b.name||'Nova campanha'),body:String(b.body||'')}})
 if(Array.isArray(b.attachments) && b.attachments.length){await prisma.campaignAttachment.createMany({data:b.attachments.map((a:any)=>({campaignId:c.id,type:a.type,filename:a.filename,path:a.path,mimeType:a.mimeType,size:Number(a.size||0)}))})}
 if(contacts.length) await prisma.campaignMessage.createMany({data:contacts.map(x=>({campaignId:c.id,contactId:x.id}))})
 if(b.startNow){await prisma.campaign.update({where:{id:c.id},data:{status:'QUEUED',startedAt:new Date()}});const msgs=await prisma.campaignMessage.findMany({where:{campaignId:c.id}});for(const m of msgs)await campaignQueue.add(`send-${m.id}`,{messageId:m.id},{removeOnComplete:100,removeOnFail:100})}
 return NextResponse.json({campaign:c,contacts:contacts.length})
}
