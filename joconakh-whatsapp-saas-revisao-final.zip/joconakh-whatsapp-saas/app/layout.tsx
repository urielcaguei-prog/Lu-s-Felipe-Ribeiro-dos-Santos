import type { Metadata } from 'next'
import './globals.css'
export const metadata: Metadata={title:'JOCONAKH • WhatsApp Studio',description:'Studio profissional de comunicação via WhatsApp'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
