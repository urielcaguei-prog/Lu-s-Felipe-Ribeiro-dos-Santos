import { Worker } from 'bullmq'
import { prisma } from './lib/prisma'
const connection={url:process.env.REDIS_URL||'redis://127.0.0.1:6379'}
const appUrl=process.env.APP_URL||'http://localhost:3000'
const secret=process.env.INTERNAL_API_SECRET||''
new Worker('campaign-send',async job=>{
  const r=await fetch(`${appUrl}/api/internal/send`,{method:'POST',headers:{'Content-Type':'application/json','x-internal-secret':secret},body:JSON.stringify({messageId:job.data.messageId})})
  if(!r.ok) throw new Error(await r.text())
},{connection,concurrency:1})
console.log('JOCONAKH worker online')
