# JOCONAKH WhatsApp Studio

Painel Next.js para conexão real com WhatsApp via Baileys, contatos, campanhas, anexos e fila BullMQ.

## O que é real
- QR Code emitido pela sessão Baileys.
- Código de pareamento quando a versão instalada do Baileys oferecer o método.
- Sessão persistente em disco no diretório `WA_AUTH_DIR`.
- Envio de texto e anexos por Baileys.
- Opt-out automático para palavras SAIR/PARAR/STOP/CANCELAR recebidas.
- PostgreSQL para contatos/campanhas/auditoria.
- Redis + BullMQ para fila de campanhas.

## Requisitos
Node.js 20+; PostgreSQL; Redis.

## Rodar
1. Copie `.env.example` para `.env` e altere `ADMIN_EMAIL`, `ADMIN_PASSWORD` e `SESSION_SECRET`.
2. Para desenvolvimento local, use um `.env` com `DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:5432/joconakh"` e `REDIS_URL="redis://127.0.0.1:6379"`.
3. `docker compose up -d`
4. `npm install`
5. `npx prisma generate`
6. `npx prisma migrate dev --name init`
7. Terminal 1: `npm run dev`
8. Terminal 2: `npm run worker`
9. Abra `http://localhost:3000`.

Para produção Docker, use o `.env` com os nomes de serviço `postgres` e `redis` conforme o `docker-compose.prod.yml`. Nunca publique o `.env` real no GitHub.

## Produção / Netlify
A interface Next.js pode ser hospedada no Netlify, que suporta App Router, SSR e Route Handlers. Porém, o projeto completo **não deve ser tratado como um deploy puramente serverless**: a sessão Baileys e o worker BullMQ precisam de processo Node persistente, armazenamento persistente e Redis. Para o sistema completo, use um host/container persistente para o runtime do WhatsApp/worker e, se quiser, Netlify para a camada web.

O código usa `useMultiFileAuthState` como implementação inicial de sessão. A documentação atual do Baileys recomenda um auth store próprio baseado em banco para produção; portanto esta versão ainda requer essa etapa antes de ser considerada pronta para produção crítica.

## Envio responsável
A interface exige opt-in para campanhas. Não use o sistema para spam, listas compradas ou para contornar bloqueios/limites da plataforma. Baileys é uma biblioteca não oficial.

## Revisão desta versão

- Login privado mantido; não há aba/painel administrativo separado.
- Campanhas aceitam números diretamente no compositor, um por linha, com confirmação explícita de opt-in.
- A sessão do WhatsApp permanece em volume persistente.
- O botão de desconexão encerra o socket sem chamar logout da conta, preservando a sessão local para reconexão.
- O projeto ainda depende de um processo Node persistente para Baileys e de um worker BullMQ.
- `useMultiFileAuthState` continua sendo uma implementação inicial; para produção crítica, substitua por armazenamento de credenciais em banco/armazenamento seguro.
- Não foi possível executar `npm install`/`next build` neste ambiente porque a instalação excedeu o limite de tempo; portanto esta revisão não é uma certificação de build.
